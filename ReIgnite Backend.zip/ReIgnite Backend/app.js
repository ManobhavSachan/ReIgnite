const express               =  require('express'),
      app                   =  express(),
      mongoose              =  require("mongoose"),
      passport              =  require("passport"),
      bodyParser            =  require("body-parser"),
      LocalStrategy         =  require("passport-local"),
      passportLocalMongoose =  require("passport-local-mongoose"),
      User                  =  require("./models/user");


//Connecting database
mongoose.connect("mongodb://localhost/auth_demo");

app.use(require("express-session")({
    secret:"Any normal Word",       //decode or encode session
    resave: false,
    saveUninitialized:false
}));

app.use(express.static('assets'));

// projectDirectory/src/index.js
// const path = require('path')
// const publicDirectoryPath = path.join(__dirname, '../assets')
// app.use(express.static(publicDirectoryPath))

// projectDirectory/public -> create index.html
// localhost:3000/index.html -> Here you go..

// app.use(express.static('assets'));

passport.serializeUser(User.serializeUser());       //session encoding
passport.deserializeUser(User.deserializeUser());   //session decoding
passport.use(new LocalStrategy(User.authenticate()));
app.set("view engine","ejs");
app.use(bodyParser.urlencoded(
      { extended:true }
))
app.use(passport.initialize());
app.use(passport.session());

//=======================

app.get("/", (req,res) =>{
    res.render("home");
})

app.get("/home",(req,res)=>{
    res.render("home");
});

app.get("/contact",(req,res)=>{
    res.render("contact");
});
// app.get("/jobindex",(req,res)=>{
//     res.render("jobindex");
// });
app.get("/courseindex",(req,res)=>{
    res.render("courseindex");
});
app.get("/scemeindex",(req,res)=>{
    res.render("scemeindex");
});



app.get("/jobindex",isLoggedIn ,(req,res) =>{
    res.render("jobindex");
})
//Auth Routes
app.get("/login",(req,res)=>{
    res.render("LogInIndex");
});

app.post("/login",passport.authenticate("local",{
    successRedirect:"/jobindex",
    failureRedirect:"/login"
}),function (req, res){
  console.log("User is successfully Logged In");
});

app.get("/register",(req,res)=>{
    res.render("register");
});

app.post("/register",(req,res)=>{

    User.register(new User({username: req.body.username,phone:req.body.phone,telephone: req.body.telephone}),req.body.password,function(err,user){
        if(err){
            console.log(err);
            alert(err);
            res.render("register");
        }
        console.log(user);
    passport.authenticate("local")(req,res,function(){
        res.redirect("/login");
    })
    })
})

app.get("/logout",(req,res)=>{
    req.logout();
    res.redirect("/");
});

function isLoggedIn(req,res,next) {
    if(req.isAuthenticated()){
        return next();
    }
    res.redirect("/login");
}


//Listen On Server


app.listen(process.env.PORT ||3000,function (err) {
    if(err){
        console.log(err);
    }else {
        console.log("Server Started At Port 3000");
    }

});
